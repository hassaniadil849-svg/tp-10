package ma.projet.tp10;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class MsgAdapter extends RecyclerView.Adapter<MsgViewHolder> {
    private List<Message> messageList;

    public MsgAdapter(List<Message> messageList) {
        this.messageList = messageList;
    }

    @NonNull
    @Override
    public MsgViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.msgitem, parent, false);
        return new MsgViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MsgViewHolder holder, int position) {
        Message msg = messageList.get(position);
        holder.msgTv.setText(msg.getMsg());
        holder.authorTv.setText(" - " + msg.getAuthor());

        // --- PARTIE 8 : SUPPRESSION (CLIC LONG) ---
        holder.itemView.setOnLongClickListener(v -> {
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("msg");
            // Supprime le message en utilisant sa clé unique [cite: 378, 381]
            ref.child(msg.getKey()).removeValue();
            return true;
        });

        // --- PARTIE 9 : MODIFICATION (CLIC SIMPLE) ---
        holder.itemView.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
            builder.setTitle("Modifier le message");

            final EditText input = new EditText(v.getContext());
            input.setText(msg.getMsg()); // Pré-remplir avec le texte actuel [cite: 396, 419]
            builder.setView(input);

            builder.setPositiveButton("Modifier", (dialog, which) -> {
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("msg");
                msg.setMsg(input.getText().toString()); // Mettre à jour l'objet local [cite: 433]
                ref.child(msg.getKey()).setValue(msg); // Enregistrer dans Firebase [cite: 433, 438]
            });

            builder.setNegativeButton("Annuler", null);
            builder.show();
        });
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }
}